<script setup>
import { ref } from 'vue'

</script>

<template>
  <table>

    <thead>
      <tr>
        <th>Marque</th><th>Couleur</th><th>Stock</th>
      </tr>
    </thead>

    <tbody id="app">
      <tr v-for="toto in entrepots">
        <td>{{ toto.Marque }}</td>
        <td>{{ toto.Couleur }}</td>
        <td>{{ toto.Stock }}</td>
      </tr>
    </tbody>

    <tfoot>
      <tr>
        <td colspan="3">Délais sur commande très rapide</td>
      </tr>
    </tfoot>

  </table>
</template>

<script>

export default{
  data () {
    return {
      entrepots: []
    }  
  },

  mounted () {
    axios
      .get('./assets/entrepots.json')
      .then(response => (this.entrepots = response.data.entrepots))
  }
}
</script>

<style scoped>
a {
  color: #42b983;
}
</style>
